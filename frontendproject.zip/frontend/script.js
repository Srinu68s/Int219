document.addEventListener("DOMContentLoaded", function () {
    const inputText = document.getElementById("inputText");
    const domainSelect = document.getElementById("domainSelect");
    const translateBtn = document.getElementById("translateBtn");
    const loaderIcon = document.getElementById("loaderIcon");
    const outputText = document.getElementById("outputText");
    const charCount = document.getElementById("charCount");
  
    const API_URL = "http://localhost:5000/api/translate";
  
    // Update character counter
    inputText.addEventListener("input", () => {
      charCount.textContent = `${inputText.value.length}/5000`;
    });
  
    // Translate button click
    translateBtn.addEventListener("click", async () => {
      const text = inputText.value.trim();
      const domain = domainSelect.value;
  
      if (text === "") {
        outputText.innerHTML = `<p class="text-red-500">Please enter some English text to translate.</p>`;
        return;
      }
  
      loaderIcon.classList.remove("hidden");
  
      try {
        const response = await fetch(API_URL, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + localStorage.getItem("token") // Optional, if using auth
          },
          body: JSON.stringify({ text, domain })
        });
  
        const data = await response.json();
        loaderIcon.classList.add("hidden");
  
        if (data.success) {
          outputText.innerHTML = `<p class="text-gray-800 devanagari">${data.hindi}</p>`;
        } else {
          outputText.innerHTML = `<p class="text-red-500">${data.error}</p>`;
        }
      } catch (error) {
        loaderIcon.classList.add("hidden");
        outputText.innerHTML = `<p class="text-red-500">Server error. Try again later.</p>`;
        console.error(error);
      }
    });
  
    // Clear button
    document.getElementById("clearBtn").addEventListener("click", () => {
      inputText.value = "";
      charCount.textContent = "0/5000";
      outputText.innerHTML = `<p class="text-gray-400">Translated Hindi text will appear here...</p>`;
    });
  
    // Copy button
    document.getElementById("copyBtn").addEventListener("click", () => {
      const text = outputText.innerText;
      if (!text || text.includes("Translated Hindi text will appear here")) return;
  
      navigator.clipboard.writeText(text).then(() => {
        alert("Copied to clipboard!");
      });
    });
  
    // Speak button
    document.getElementById("speakBtn").addEventListener("click", () => {
      const text = outputText.innerText;
      if (!text) return;
  
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "hi-IN";
      speechSynthesis.speak(utterance);
    });
  
    // Save as PDF
    document.getElementById("saveBtn").addEventListener("click", () => {
      const text = outputText.innerText;
      if (!text) return;
  
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      doc.setFont("NotoSansDevanagari", "normal");
      doc.setFontSize(14);
      doc.text(text, 10, 20);
      doc.save("Hindi_Translation.pdf");
    });
  });

  